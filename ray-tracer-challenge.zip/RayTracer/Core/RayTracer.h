#ifndef RAYTRACER_H
#define RAYTRACER_H

#include "DataTypes.hpp"
#include "Ray.hpp"

#include <vector>
#include <string>
#include <memory>

namespace ray_tracer {

class RayTracer
{
private:

public:
    RayTracer() = default;

    ~RayTracer() = default;
};

} // namespace ray_tracer

#endif // RAYTRACER_H
