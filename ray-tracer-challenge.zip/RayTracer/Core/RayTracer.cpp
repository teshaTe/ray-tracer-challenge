#include "RayTracer.h"

namespace ray_tracer {

} // namespace ray_tracer
